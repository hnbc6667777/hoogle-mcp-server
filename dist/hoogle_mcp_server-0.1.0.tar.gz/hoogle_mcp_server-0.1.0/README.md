# Hoogle MCP Server

一个 Model Context Protocol (MCP) 服务器，用于查询 Hoogle (Haskell API 搜索引擎)。

## 功能特性

- 🔍 搜索 Haskell 函数和类型签名
- 📚 获取详细的函数信息（名称、类型签名、文档）
- 🚀 快速的异步请求处理
- 📖 结构化的结果返回格式
- 🌐 支持中文界面

## 安装

### 前置要求

- Python 3.8+
- pip 包管理器

### 从 PyPI 安装（推荐）

```bash
pip install hoogle-mcp-server
```

### 从源码安装

1. 克隆仓库：
```bash
git clone <repository-url>
cd hoogle-mcp-server
```

2. 安装依赖：
```bash
pip install -r requirements.txt
```

或者直接安装所需包：
```bash
pip install mcp fastmcp requests beautifulsoup4
```

## 配置

### 从 PyPI 安装后的配置

在 Claude Desktop 的配置文件中添加以下内容：

```json
{
  "mcpServers": {
    "hoogle": {
      "command": "hoogle-mcp-server"
    }
  }
}
```

### 从源码安装的配置

在 Claude Desktop 的配置文件中添加以下内容：

```json
{
  "mcpServers": {
    "hoogle": {
      "command": "python",
      "args": [
        "main.py"
      ],
      "cwd": "（你的仓库路径）"
    }
  }
}
```

### 使用 uv 运行器

如果你使用 [uv](https://github.com/astral-sh/uv) 作为 Python 包管理器：

```json
{
  "mcpServers": {
    "hoogle": {
      "command": "uv",
      "args": [
        "--directory",
        "（你的仓库路径）",
        "run",
        "main.py"
      ]
    }
  }
}
```

## 使用方法

### 基本搜索

在 Claude 中，你可以使用以下命令搜索 Haskell 函数：

```
@hoogle search "map"
```

### 类型签名搜索

你也可以搜索特定的类型签名：

```
@hoogle search "(a -> b) -> [a] -> [b]"
```

### 搜索示例

搜索 `map` 函数：
```
@hoogle search "map"
```

搜索 `filter` 函数：
```
@hoogle search "filter"
```

搜索列表操作函数：
```
@hoogle search "[a] -> [a]"
```

## 返回结果格式

搜索结果的返回格式如下：

```
在 Hoogle 上搜索 'map' 找到 5 个结果:

1. map
   类型: (a -> b) -> [a] -> [b]
   文档: map f xs is the list obtained by applying f to each element of xs...
   链接: https://hoogle.haskell.org/...

2. Data.Map
   类型: data Map k a
   文档: A Map from keys k to values a...
   链接: https://hoogle.haskell.org/...
```

## 项目结构

```
hoogle-mcp-server/
├── main.py          # 主要的 MCP 服务器实现
├── README.md        # 项目文档
└── requirements.txt # Python 依赖包列表
```

## 依赖项

- `mcp`: Model Context Protocol 支持
- `fastmcp`: FastMCP 服务器框架
- `requests`: HTTP 请求库
- `beautifulsoup4`: HTML 解析库

## 开发

### 运行测试

```bash
python main.py
```

### 贡献

欢迎提交 Issue 和 Pull Request 来改进这个项目。

## 许可证

本项目采用 MIT 许可证。

## 相关链接

- [Hoogle 官方网站](https://hoogle.haskell.org/)
- [Model Context Protocol 文档](https://modelcontextprotocol.io/)
- [Claude Desktop](https://claude.ai/)